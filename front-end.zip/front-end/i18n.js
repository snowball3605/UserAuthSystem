// 多語言支持
let currentLanguage = 'zh_TW'; // 默認語言
let translations = {}; // 翻譯文本
var config = {};
fetch('config.json').then(response => {
  if(!response.ok) {
    throw new Error("Failed to load config.json");
  }
  return response.json();
}).then(data => {
  config = data
}).catch(error => {
  console.error(error);
});

// 在頁面加載時初始化
document.addEventListener('DOMContentLoaded', function() {
  // 嘗試從localStorage加載用戶首選語言
  const savedLanguage = localStorage.getItem('preferredLanguage');
  if (savedLanguage) {
    currentLanguage = savedLanguage;
    document.getElementById('languageSelector').value = currentLanguage;
  }
  
  // 加載翻譯
  loadTranslations(currentLanguage);
});

// 加載語言配置
async function loadTranslations(lang) {
    try {
      // 直接從前端目錄加載，而非API
      const response = await fetch(`translations/${lang}.json`);
      if (!response.ok) {
        console.error(`Failed to load translations for ${lang}`);
        if (lang !== 'zh_TW') {
          console.warn('Falling back to default language (zh_TW)');
          return loadTranslations('zh_TW');
        }
        return;
      }
      
      translations = await response.json()
      
      // 更新頁面文本
      updateAllTexts();
      
      // 更新HTML lang屬性
      document.documentElement.lang = lang.split('_')[0];
      
      // 更新頁面標題
      document.title = t('app.title');
    } catch (error) {
      console.error('Error loading translations:', error);
    }
  }

// 切換語言
function changeLanguage(newLang) {
  if (newLang === currentLanguage) return;
  
  currentLanguage = newLang;
  
  // 保存用戶語言偏好
  localStorage.setItem('preferredLanguage', newLang);
  
  // 加載新語言的翻譯
  loadTranslations(newLang);
  
  // 發送請求到後端保存用戶的語言偏好（如果用戶已登錄）
  try {
    const authToken = getAuthToken();
    if (authToken) {
      fetch(config.apiUrl+'/api/user/preferences', {
        method: 'POST',
        credentials: "include",
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authToken
        },
        body: JSON.stringify({ preferredLanguage: newLang })
      });
    }
  } catch (error) {
    console.error('Error saving language preference:', error);
  }
}

function t(key) {
  // 按點分隔的路徑獲取翻譯對象中的值
  const path = key.split('.');
  let value = translations;
  for (const segment of path) {
    if (value && value[segment] !== undefined) {
      value = value[segment];
    } else {
      return key; // 返回鍵名作為後備
    }
  }
  
  return value;
}

// 更新所有頁面文本
function updateAllTexts() {
  // 更新所有帶有 data-i18n 屬性的元素
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    element.textContent = t(key);
  });
  
  // 更新所有帶有 data-i18n-placeholder 屬性的元素
  document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
    const key = element.getAttribute('data-i18n-placeholder');
    element.placeholder = t(key);
  });
  
  // 更新動態加載的內容，例如任務列表
  if (typeof renderTasks === 'function') {
    renderTasks();
  }
  
  // 更新模態框中的選項
  document.querySelectorAll('option[data-i18n]').forEach(option => {
    const key = option.getAttribute('data-i18n');
    option.textContent = t(key);
  });
}

// 獲取授權token的輔助函數
function getAuthToken() {
  return sessionStorage.getItem('authToken');
}