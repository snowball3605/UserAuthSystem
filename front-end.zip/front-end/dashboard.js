var config = {};
async function load() {
  fetch('config.json').then(response => {
    if(!response.ok) {
      throw new Error("Failed to load config.json");
    }
    return response.json();
  }).then(data => {
    config = data
    loadSettings();
    updateProfileAvatar();
    initDarkMode();
    checkUserPermissions();
    v();

  }).catch(error => {
    console.error(error);
  });
}
async function v() {
  try {
    const response = await fetch(config.apiUrl+'/api/me', {
      credentials: "include",
    });
    
    if (response.status !== 200) {
      window.location.href = "index.html"
    }
  } catch (error) {
    console.error('檢查用戶權限失敗:', error);
  }
}
load();
function initDarkMode() {
  // Check for system preference
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.documentElement.classList.add('dark');
  }
  
  // Toggle dark mode on button click
  const darkModeToggle = document.getElementById('darkModeToggle');
  darkModeToggle.addEventListener('click', () => {
    document.documentElement.classList.toggle('dark');
  });
  
  // Listen for system preference changes
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
    if (event.matches) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  });
}

// 檢查用戶權限並控制界面元素的顯示
async function checkUserPermissions() {
  try {
    const response = await fetch(config.apiUrl+'/api/me', {
      credentials: "include",
    });
    
    if (!response.ok) {
      throw new Error('獲取用戶信息失敗');
    }
    
    const user = await response.json();
    const isAdmin = user.role === 3;
    
    // 日誌菜單只對管理員顯示
    const logMenuItem = document.getElementById('logMenuItem');
    if (logMenuItem) {
      logMenuItem.style.display = isAdmin ? 'block' : 'none';
    }
    
    // 創建公告按鈕只對管理員顯示
    const createAnnouncementBtn = document.getElementById('createAnnouncementBtn');
    if (createAnnouncementBtn) {
      createAnnouncementBtn.style.display = isAdmin ? 'block' : 'none';
    }
    return isAdmin;
  } catch (error) {
    console.error('檢查用戶權限失敗:', error);
  }
}

// 更新頭像
function updateProfileAvatar() {
  const savedAvatar = localStorage.getItem('avatar');
  const profileAvatar = document.getElementById('profileAvatar');
  if (savedAvatar && profileAvatar) {
    profileAvatar.src = savedAvatar;
  }
}

// 加載保存的用戶設定
async function loadSettings() {
  try {
    const response = await fetch(config.apiUrl+'/api/api/user/settings', {
      credentials: "include",
      headers: {
        
        'Access-Control-Allow-Origin': '*'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const settings = await response.json();
    if (settings) {
      // 更新頭像
      const profileAvatar = document.getElementById('profileAvatar');
      if (profileAvatar) {
        profileAvatar.src = settings.avatar || 'default-avatar.png';
      }
    }
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

// 顯示或隱藏設定菜單
function toggleSettingsMenu() {
  const settingsMenu = document.getElementById('settingsMenu');
  if (settingsMenu.style.display === 'block') {
    settingsMenu.style.display = 'none';
  } else {
    settingsMenu.style.display = 'block';
  }
}

// 跳轉到設定頁面
function goToSettings() {
  window.location.href = 'settings.html';
}

// 顯示指定頁面
function showPage(pageId) {
  // 隱藏所有頁面
  document.querySelectorAll('.page').forEach(page => {
    page.style.display = 'none';
  });

  // 顯示目標頁面
  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.style.display = 'block';
  }

  // 根據頁面ID加載相應數據
  if (pageId === 'userList') {
    fetchUsers();
  } else if (pageId === 'announcements') {
    fetchAnnouncements();
  } else if (pageId === 'logs') {
    fetchLogs();
  }
}

// 初始化：顯示主頁
document.addEventListener('DOMContentLoaded', () => {
  showPage('home');
});

// -------------------- 日誌功能相關代碼 --------------------

// 當前日誌頁碼和每頁顯示數量
let currentLogPage = 1;
const logsPerPage = 20;

// 獲取日誌列表
async function fetchLogs() {
  try {
    // 顯示加載指示器
    const logTableBody = document.getElementById('logTableBody');
    logTableBody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center py-8">
          <i class="fas fa-spinner fa-spin text-primary text-3xl"></i>
          <p class="mt-2">正在加載日誌數據...</p>
        </td>
      </tr>
    `;
    
    // 獲取過濾條件
    const typeFilter = document.getElementById('logTypeFilter').value;
    const dateFilter = document.getElementById('logDateRangeFilter').value;
    const searchQuery = document.getElementById('logSearch').value;
    
    // 構建查詢參數
    const queryParams = new URLSearchParams({
      page: currentLogPage,
      limit: logsPerPage,
      type: typeFilter !== 'all' ? typeFilter : '',
      dateRange: dateFilter !== 'all' ? dateFilter : '',
      search: searchQuery
    });
    
    const response = await fetch(config.apiUrl+`/api/logs?${queryParams.toString()}`, {
      credentials: "include",
      headers: {
        
        'Access-Control-Allow-Origin': '*'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json()
    renderLogss(data.logs, data.total);
    updateLogStats(data.stats);
    
  } catch (error) {
    console.error('Failed to fetch logs:', error);
    // 如果API請求失敗，顯示錯誤提示
    showErrorNotification(t('errors.failedToLoadLogs'));
  }
}

// 渲染日誌列表
function renderLogss(logs, totalLogs) {
  const logTableBody = document.getElementById('logTableBody');
  logTableBody.innerHTML = '';
  

  if (!logs || logs.length === 0) {
    logTableBody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center py-8 text-gray-500">
          <i class="fas fa-search text-4xl mb-2"></i>
          <p>沒有找到符合條件的日誌記錄</p>
        </td>
      </tr>
    `;
    
    // 清空分頁
    document.getElementById('logPagination').innerHTML = '';
    return;
  }

  logs.forEach(log => {
    const tr = document.createElement('tr');
    tr.className = `log-row ${log.type}-type clickable-row`;
    tr.dataset.logId = log.id;
    
    // 格式化時間
    const logTime = new Date(log.timestamp);
    const formattedTime = logTime.toLocaleString('zh-TW', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    
    // 根據操作類型設置不同的標籤樣式
    const logTypeMap = {
      'login': { name: '登入', icon: 'sign-in-alt' },
      'user': { name: '用戶管理', icon: 'user-plus' },
      'role': { name: '權限變更', icon: 'user-shield' },
      'announcement': { name: '公告管理', icon: 'bullhorn' },
      'settings': { name: '設定變更', icon: 'cog' }
    };
    
    const typeInfo = logTypeMap[log.type] || { name: '其他操作', icon: 'circle' };
    
    tr.innerHTML = `
      <td class="whitespace-nowrap">${formattedTime}</td>
      <td>${log.userEmail || '系統'}</td>
      <td>
        <span class="log-tag ${log.type}">
          <i class="fas fa-${typeInfo.icon} mr-1"></i> ${typeInfo.name}
        </span>
      </td>
      <td>${log.description}</td>
      <td>${log.ipAddress || '-'}</td>
    `;
    
    // 添加點擊事件
    tr.addEventListener('click', () => showLogDetail(log));
    
    logTableBody.appendChild(tr);
  });
  
  // 生成分頁
  renderPagination(totalLogs, logsPerPage, currentLogPage);
}

// 渲染分頁
function renderPagination(totalItems, itemsPerPage, currentPage) {
  const paginationContainer = document.getElementById('logPagination');
  paginationContainer.innerHTML = '';
  
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  if (totalPages <= 1) return;
  
  const paginationList = document.createElement('div');
  paginationList.className = 'pagination';
  
  // 上一頁按鈕
  const prevItem = document.createElement('div');
  prevItem.className = `pagination-item ${currentPage === 1 ? 'disabled' : ''}`;
  prevItem.innerHTML = '<i class="fas fa-chevron-left"></i>';
  if (currentPage > 1) {
    prevItem.addEventListener('click', () => {
      currentLogPage--;
      fetchLogs();
    });
  }
  paginationList.appendChild(prevItem);
  
  // 最多顯示5個頁碼
  let startPage = Math.max(1, currentPage - 2);
  let endPage = Math.min(totalPages, startPage + 4);
  
  if (endPage - startPage < 4) {
    startPage = Math.max(1, endPage - 4);
  }
  
  // 如果當前頁碼距離頭部過遠，顯示第一頁和省略號
  if (startPage > 1) {
    const firstItem = document.createElement('div');
    firstItem.className = 'pagination-item';
    firstItem.textContent = '1';
    firstItem.addEventListener('click', () => {
      currentLogPage = 1;
      fetchLogs();
    });
    paginationList.appendChild(firstItem);
    
    if (startPage > 2) {
      const ellipsis = document.createElement('div');
      ellipsis.className = 'pagination-item disabled';
      ellipsis.innerHTML = '...';
      paginationList.appendChild(ellipsis);
    }
  }
  
  // 頁碼按鈕
  for (let i = startPage; i <= endPage; i++) {
    const pageItem = document.createElement('div');
    pageItem.className = `pagination-item ${i === currentPage ? 'active' : ''}`;
    pageItem.textContent = i;
    
    if (i !== currentPage) {
      pageItem.addEventListener('click', () => {
        currentLogPage = i;
        fetchLogs();
      });
    }
    
    paginationList.appendChild(pageItem);
  }
  
  // 如果當前頁碼距離尾部過遠，顯示省略號和最後一頁
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      const ellipsis = document.createElement('div');
      ellipsis.className = 'pagination-item disabled';
      ellipsis.innerHTML = '...';
      paginationList.appendChild(ellipsis);
    }
    
    const lastItem = document.createElement('div');
    lastItem.className = 'pagination-item';
    lastItem.textContent = totalPages;
    lastItem.addEventListener('click', () => {
      currentLogPage = totalPages;
      fetchLogs();
    });
    paginationList.appendChild(lastItem);
  }
  
  // 下一頁按鈕
  const nextItem = document.createElement('div');
  nextItem.className = `pagination-item ${currentPage === totalPages ? 'disabled' : ''}`;
  nextItem.innerHTML = '<i class="fas fa-chevron-right"></i>';
  if (currentPage < totalPages) {
    nextItem.addEventListener('click', () => {
      currentLogPage++;
      fetchLogs();
    });
  }
  paginationList.appendChild(nextItem);
  
  paginationContainer.appendChild(paginationList);
}

// 更新日誌統計信息
function updateLogStats(stats) {
  document.getElementById('totalLogCount').textContent = stats.totalCount || 0;
  document.getElementById('loginCount').textContent = stats.loginCount || 0;
  document.getElementById('roleChangeCount').textContent = stats.roleChangeCount || 0;
  document.getElementById('mostActiveUser').textContent = stats.mostActiveUser || '-';
}

// 顯示日誌詳情
function showLogDetail(log) {
  const modal = document.getElementById('logDetailModal');
  
  // 格式化時間
  const logTime = new Date(log.timestamp);
  const formattedTime = logTime.toLocaleString('zh-TW', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  
  // 設置詳情內容
  document.getElementById('logDetail-time').textContent = formattedTime;
  document.getElementById('logDetail-user').textContent = log.userEmail || '系統';
  document.getElementById('logDetail-ip').textContent = log.ipAddress || '-';
  
  // 根據操作類型設置不同的顯示
  const logTypeMap = {
    'login': '登入',
    'user': '用戶管理',
    'role': '權限變更',
    'announcement': '公告管理',
    'settings': '設定變更'
  };
  
  document.getElementById('logDetail-type').textContent = logTypeMap[log.type] || '其他操作';
  document.getElementById('logDetail-description').textContent = log.description;
  
  // 格式化並顯示詳細數據
  try {
    const formattedData = JSON.stringify(log.data, null, 2);
    document.getElementById('logDetail-data').textContent = formattedData;
  } catch (error) {
    document.getElementById('logDetail-data').textContent = '無詳細數據';
  }
  
  // 顯示模態框
  modal.style.display = 'block';
}

// 關閉日誌詳情模態框
function closeLogDetailModal() {
  document.getElementById('logDetailModal').style.display = 'none';
}

// 刷新日誌列表
function refreshLogs() {
  // 重置頁碼
  currentLogPage = 1;
  fetchLogs();
}

// 導出日誌
function exportLogs() {
  // 獲取過濾條件
  const typeFilter = document.getElementById('logTypeFilter').value;
  const dateFilter = document.getElementById('logDateRangeFilter').value;
  const searchQuery = document.getElementById('logSearch').value;
  
  // 構建查詢參數
  const queryParams = new URLSearchParams({
    export: true,
    type: typeFilter !== 'all' ? typeFilter : '',
    dateRange: dateFilter !== 'all' ? dateFilter : '',
    search: searchQuery
  });
  
  // 打開導出 URL
  window.open(config.apiUrl+`/api/logs/export?${queryParams.toString()}`);
}

// 設置日誌篩選事件
document.addEventListener('DOMContentLoaded', () => {
  const logTypeFilter = document.getElementById('logTypeFilter');
  const logDateRangeFilter = document.getElementById('logDateRangeFilter');
  const logSearch = document.getElementById('logSearch');
  
  if (logTypeFilter && logDateRangeFilter && logSearch) {
    logTypeFilter.addEventListener('change', () => {
      currentLogPage = 1;
      fetchLogs();
    });
    
    logDateRangeFilter.addEventListener('change', () => {
      currentLogPage = 1;
      fetchLogs();
    });
    
    let searchTimeout;
    logSearch.addEventListener('input', () => {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        currentLogPage = 1;
        fetchLogs();
      }, 500);
    });
  }
});

// -------------------- 用戶管理相關代碼 --------------------

// 獲取用戶列表
async function fetchUsers() {
  try {
    // 顯示加載指示器
    const userListContent = document.getElementById('userListContent');
    userListContent.innerHTML = '<div class="p-4 text-center"><i class="fas fa-spinner fa-spin text-3xl text-primary"></i><p class="mt-2">正在加載用戶資料...</p></div>';
    
    const response = await fetch(config.apiUrl+'/api/api/users', {
      credentials: "include",
      headers: {
        
        'Access-Control-Allow-Origin': '*'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const users = await response.json();
    renderUserList(users);
  } catch (error) {
    console.error('Failed to fetch users:', error);
    // 顯示錯誤訊息
    const userListContent = document.getElementById('userListContent');
    userListContent.innerHTML = `<div class="p-4 text-center text-danger"><i class="fas fa-exclamation-circle text-3xl mb-2"></i><p>加載用戶失敗: ${error.message}</p></div>`;
  }
}

// 渲染用戶列表
function renderUserList(users) {
  const userListContent = document.getElementById('userListContent');
  userListContent.innerHTML = '';

  if (users.length === 0) {
    userListContent.innerHTML = '<div class="p-4 text-center text-gray-500"><i class="fas fa-users text-4xl mb-2"></i><p>沒有找到用戶</p></div>';
    return;
  }

  users.forEach(user => {
    const userCard = document.createElement('div');
    userCard.className = 'user-card';

    // 用戶頭像處理
    const hasAvatar = user.avatar && user.avatar.trim() !== '';
    
    // 如果沒有頭像，使用首字母和顏色背景
    const initials = user.email.charAt(0).toUpperCase();
    const bgColors = ['#5D5CDE', '#48BB78', '#ED8936', '#9F7AEA', '#E53E3E'];
    const randomColor = bgColors[Math.floor(Math.random() * bgColors.length)];

    // 準備頭像 HTML
    let avatarHtml = '';
    if (hasAvatar) {
      // 使用實際頭像
      avatarHtml = `<img src="${user.avatar}" alt="${initials}" class="w-10 h-10 rounded-full object-cover border-2 border-primary">`;
    } else {
      // 使用首字母頭像
      avatarHtml = `<div class="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style="background-color: ${randomColor}">
        ${initials}
      </div>`;
    }

    // 顯示用戶信息
    userCard.innerHTML = `
      <div class="flex items-center gap-4">
        ${avatarHtml}
        <div class="flex-1">
          <div class="user-email">${user.email}</div>
          <div class="user-role">
            <span class="inline-flex items-center">
              <i class="fas fa-shield-alt mr-1"></i>
              ${getRoleName(user.role)}
            </span>
          </div>
        </div>
      </div>
      <div class="user-controls mt-4">
        <select class="form-select roleSelect" data-email="${user.email}">
          <option value="0" ${user.role === 0 ? 'selected' : ''}>被封鎖</option>
          <option value="1" ${user.role === 1 ? 'selected' : ''}>只讀</option>
          <option value="2" ${user.role === 2 ? 'selected' : ''}>編輯</option>
          <option value="3" ${user.role === 3 ? 'selected' : ''}>管理員</option>
        </select>
        <button class="btn btn-danger" data-email="${user.email}" onclick="showDeleteUserModal('${user.email}')">
          <i class="fas fa-trash-alt mr-1"></i>
          刪除
        </button>
      </div>
    `;

    // 監聽權限更改
    const roleSelect = userCard.querySelector('.roleSelect');
    roleSelect.addEventListener('change', (e) => {
      updateUserRole(user.email, parseInt(e.target.value));
    });

    userListContent.appendChild(userCard);
  });
}

// 更新用戶權限
async function updateUserRole(email, role) {
  try {
    // 顯示加載效果
    const roleSelect = document.querySelector(`.roleSelect[data-email="${email}"]`);
    roleSelect.disabled = true;
    
    const response = await fetch(config.apiUrl+`/api/api/users/${email}`, {
      method: 'PUT',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
        
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ role })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();
    if (result.success) {
      
      // 顯示成功提示
      showNotification('權限更新成功', 'success');
      
      fetchUsers(); // 刷新用戶列表
    } else {
      showNotification(`權限更新失敗: ${result.message}`, 'error');
    }
  } catch (error) {
    console.error('Failed to update user role:', error);
    showNotification(`更新用戶權限失敗: ${error.message}`, 'error');
  } finally {
    // 恢復輸入控制項
    const roleSelect = document.querySelector(`.roleSelect[data-email="${email}"]`);
    if (roleSelect) roleSelect.disabled = false;
  }
}

// 獲取權限名稱
function getRoleName(role) {
  switch (role) {
    case 0: return '被封鎖';
    case 1: return '只讀';
    case 2: return '編輯';
    case 3: return '管理員';
    default: return '未知';
  }
}

// -------------------- 公告管理相關代碼 --------------------

// 獲取公告列表
async function fetchAnnouncements() {
  try {
    // 顯示加載指示器
    const announcementsContainer = document.getElementById('announcementsContainer');
    announcementsContainer.innerHTML = `
      <div class="loading-indicator">
        <i class="fas fa-spinner fa-spin text-primary text-3xl"></i>
        <p class="mt-2">載入公告中...</p>
      </div>
    `;
    
    const response = await fetch(config.apiUrl+'/api/announcements', {
      credentials: "include",
      headers: {
        
        'Access-Control-Allow-Origin': '*'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const announcements = await response.json();
    renderAnnouncements(announcements);
    
    // 設置篩選器事件監聽
    setupAnnouncementFilters();
  } catch (error) {
    console.error('Failed to fetch announcements:', error);
    const announcementsContainer = document.getElementById('announcementsContainer');
    announcementsContainer.innerHTML = `
      <div class="p-4 text-center text-danger">
        <i class="fas fa-exclamation-circle text-3xl mb-2"></i>
        <p>加載公告失敗: ${error.message}</p>
      </div>
    `;
  }
}

// 渲染公告列表
function renderAnnouncements(announcements) {
  const announcementsContainer = document.getElementById('announcementsContainer');
  announcementsContainer.innerHTML = '';

  if (!announcements || announcements.length === 0) {
    announcementsContainer.innerHTML = `
      <div class="no-announcements">
        <i class="fas fa-bullhorn text-4xl mb-2"></i>
        <p>目前沒有公告</p>
      </div>
    `;
    return;
  }

  // 對公告按時間排序，最新的在前面
  announcements.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  announcements.forEach(announcement => {
    const announcementCard = document.createElement('div');
    const isImportant = announcement.type === 'important';
    
    announcementCard.className = `announcement-card ${isImportant ? 'important' : ''}`;
    announcementCard.dataset.id = announcement.id;
    announcementCard.dataset.type = announcement.type;

    // 格式化日期
    const createdAt = new Date(announcement.createdAt);
    const formattedDate = createdAt.toLocaleDateString('zh-TW', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    // 添加公告內容
    announcementCard.innerHTML = `
      <div class="announcement-header">
        <h3 class="announcement-title">${announcement.title}</h3>
      </div>
      <div class="announcement-meta">
        <span class="announcement-tag ${isImportant ? 'important' : ''}">${isImportant ? '重要公告' : '一般通知'}</span>
        <span class="announcement-date">
          <i class="far fa-calendar-alt mr-1"></i>${formattedDate}
        </span>
        <span class="announcement-author">
          <i class="far fa-user mr-1"></i>${announcement.author || '管理員'}
        </span>
      </div>
      <div class="announcement-content">${announcement.content}</div>
      <div class="announcement-actions">
        <button class="btn btn-ghost" onclick="viewAnnouncement('${announcement.id}')">
          <i class="fas fa-eye mr-1"></i>查看
        </button>
      </div>
    `;

    announcementsContainer.appendChild(announcementCard);
  });
}

// 設置公告篩選與搜尋
function setupAnnouncementFilters() {
  const announcementFilter = document.getElementById('announcementFilter');
  const announcementSearch = document.getElementById('announcementSearch');
  
  // 篩選事件
  announcementFilter.addEventListener('change', () => {
    filterAnnouncements();
  });
  
  // 搜尋事件
  announcementSearch.addEventListener('input', () => {
    filterAnnouncements();
  });
}

// 篩選和搜尋公告
function filterAnnouncements() {
  const filterValue = document.getElementById('announcementFilter').value;
  const searchValue = document.getElementById('announcementSearch').value.toLowerCase();
  const announcementCards = document.querySelectorAll('.announcement-card');
  
  announcementCards.forEach(card => {
    const cardType = card.dataset.type;
    const cardTitle = card.querySelector('.announcement-title').textContent.toLowerCase();
    const cardContent = card.querySelector('.announcement-content').textContent.toLowerCase();
    
    // 檢查是否符合篩選條件
    const matchesFilter = filterValue === 'all' || cardType === filterValue;
    
    // 檢查是否符合搜尋條件
    const matchesSearch = cardTitle.includes(searchValue) || cardContent.includes(searchValue);
    
    // 顯示或隱藏公告卡片
    if (matchesFilter && matchesSearch) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
  
  // 檢查是否沒有可顯示的公告
  const visibleCards = document.querySelectorAll('.announcement-card[style*="display: block"]');
  const announcementsContainer = document.getElementById('announcementsContainer');
  
  if (visibleCards.length === 0) {
    // 如果沒有可見的卡片，顯示無結果提示
    if (!document.querySelector('.no-results')) {
      const noResults = document.createElement('div');
      noResults.className = 'no-announcements no-results';
      noResults.innerHTML = `
        <i class="fas fa-search text-4xl mb-2"></i>
        <p>找不到符合條件的公告</p>
      `;
      announcementsContainer.appendChild(noResults);
    }
  } else {
    // 如果有可見卡片，移除無結果提示
    const noResults = document.querySelector('.no-results');
    if (noResults) {
      noResults.remove();
    }
  }
}

// 查看公告詳情
function viewAnnouncement(id) {
  fetch(config.apiUrl+`/api/announcements/${id}`, {
    credentials: "include",
    headers: {
      
      'Access-Control-Allow-Origin': '*'
    }
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(announcement => {
      // 填充公告詳情 Modal
      document.getElementById('viewAnnouncementTitle').textContent = announcement.title;
      
      const formattedDate = new Date(announcement.createdAt).toLocaleDateString('zh-TW', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
      
      const typeElement = document.getElementById('viewAnnouncementType');
      typeElement.textContent = announcement.type === 'important' ? '重要公告' : '一般通知';
      typeElement.className = announcement.type === 'important' 
        ? 'announcement-tag important' 
        : 'announcement-tag';
      
      document.getElementById('viewAnnouncementDate').textContent = formattedDate;
      document.getElementById('viewAnnouncementAuthor').textContent = announcement.author || '管理員';
      document.getElementById('viewAnnouncementContent').textContent = announcement.content;
      
      // 檢查當前用戶是否有權限編輯/刪除公告
      checkUserPermissions().then(isAdmin => {
        const actionButtons = document.getElementById('announcementActions');
        if (isAdmin) {
          actionButtons.style.display = 'flex';
          // 保存當前公告ID用於編輯和刪除操作
          actionButtons.dataset.announcementId = id;
        } else {
          actionButtons.style.display = 'none';
        }
      });
      
      // 顯示詳情 Modal
      document.getElementById('viewAnnouncementModal').style.display = 'block';
    })
    .catch(error => {
      console.error('Failed to fetch announcement details:', error);
      // 顯示錯誤提示
      showNotification('無法獲取公告詳情', 'error');
    });
}

// -------------------- 通用函數和事件處理 --------------------

// 顯示通知訊息
function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  
  // 設置樣式
  if (type === 'success') {
    notification.className = 'fixed top-4 right-4 bg-success text-white p-4 rounded-md shadow-lg z-50 flex items-center';
    notification.innerHTML = `<i class="fas fa-check-circle mr-2"></i>${message}`;
  } else if (type === 'error') {
    notification.className = 'fixed top-4 right-4 bg-danger text-white p-4 rounded-md shadow-lg z-50 flex items-center';
    notification.innerHTML = `<i class="fas fa-exclamation-circle mr-2"></i>${message}`;
  } else if (type === 'warning') {
    notification.className = 'fixed top-4 right-4 bg-warning text-white p-4 rounded-md shadow-lg z-50 flex items-center';
    notification.innerHTML = `<i class="fas fa-exclamation-triangle mr-2"></i>${message}`;
  }
  
  document.body.appendChild(notification);
  
  // 自動移除提示
  setTimeout(() => {
    notification.classList.add('fade-out');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// 顯示新增用戶的 Modal
function showAddUserModal() {
  const modal = document.getElementById('addUserModal');
  modal.style.display = 'block';
  // 重置表單
  document.getElementById('addUserForm').reset();
  // 聚焦到第一個輸入框
  document.getElementById('email').focus();
}

// 隱藏新增用戶的 Modal
function closeAddUserModal() {
  const modal = document.getElementById('addUserModal');
  modal.style.display = 'none';
}

// 顯示刪除用戶的確認 Modal
let currentUserEmailToDelete = null;
function showDeleteUserModal(email) {
  currentUserEmailToDelete = email;
  const modal = document.getElementById('deleteUserModal');
  modal.style.display = 'block';
}

// 隱藏刪除用戶的確認 Modal
function closeDeleteUserModal() {
  const modal = document.getElementById('deleteUserModal');
  modal.style.display = 'none';
  currentUserEmailToDelete = null;
}

// 確認刪除用戶
async function confirmDeleteUser() {
  if (!currentUserEmailToDelete) return;

  try {
    // 禁用刪除按鈕並顯示加載狀態
    const deleteButton = document.querySelector('#deleteUserModal .btn-danger');
    const originalButtonText = deleteButton.innerHTML;
    deleteButton.disabled = true;
    deleteButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>處理中...';
    
    const response = await fetch(config.apiUrl+`/api/delete-account`, {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
        
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ email: currentUserEmailToDelete })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();
    if (result.success) {
      // 顯示成功提示
      showNotification('用戶刪除成功', 'success');
      
      closeDeleteUserModal(); // 關閉 Modal
      fetchUsers(); // 刷新用戶列表
    } else {
      showNotification(`用戶刪除失敗: ${result.message}`, 'error');
    }
  } catch (error) {
    console.error('Failed to delete user:', error);
    showNotification(`刪除用戶時發生錯誤: ${error.message}`, 'error');
  } finally {
    // 恢復刪除按鈕狀態
    const deleteButton = document.querySelector('#deleteUserModal .btn-danger');
    if (deleteButton) {
      deleteButton.disabled = false;
      deleteButton.innerHTML = '<i class="fas fa-trash-alt mr-2"></i>刪除';
    }
  }
}

// 處理表單提交
document.addEventListener('DOMContentLoaded', function() {
  const addUserForm = document.getElementById('addUserForm');
  if (addUserForm) {
    addUserForm.addEventListener('submit', function(e) {
      e.preventDefault(); // 阻止表單默認提交行為

      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;

      if (!email || !password) {
        showNotification('請填寫所有欄位！', 'error');
        return;
      }

      // 調用 API 新增用戶
      addUser(email, password);
    });
  }

  // 添加點擊事件，當點擊 Modal 外部時關閉 Modal
  window.addEventListener('click', function(event) {
    const modals = [
      'addUserModal', 'deleteUserModal', 'createAnnouncementModal', 
      'viewAnnouncementModal', 'deleteAnnouncementModal', 'logDetailModal'
    ];
    
    modals.forEach(modalId => {
      const modal = document.getElementById(modalId);
      if (modal && event.target === modal) {
        closeModal(modalId);
      }
    });
  });

  // 點擊頁面任何地方關閉設定選單
  document.addEventListener('click', function(event) {
    const settingsMenu = document.getElementById('settingsMenu');
    const profileAvatar = document.getElementById('profileAvatar');
    
    if (settingsMenu && settingsMenu.style.display === 'block' && 
        event.target !== settingsMenu && 
        event.target !== profileAvatar && 
        !settingsMenu.contains(event.target)) {
      settingsMenu.style.display = 'none';
    }
  });
});

// 關閉模態框的通用函數
function closeModal(modalId) {
  switch (modalId) {
    case 'addUserModal':
      closeAddUserModal();
      break;
    case 'deleteUserModal':
      closeDeleteUserModal();
      break;
    case 'createAnnouncementModal':
      closeCreateAnnouncementModal();
      break;
    case 'viewAnnouncementModal':
      closeViewAnnouncementModal();
      break;
    case 'deleteAnnouncementModal':
      closeDeleteAnnouncementModal();
      break;
    case 'logDetailModal':
      closeLogDetailModal();
      break;
    default:
      document.getElementById(modalId).style.display = 'none';
  }
}

// 新增用戶的 API 請求
async function addUser(email, password) {
  try {
    // 禁用提交按鈕並顯示加載狀態
    const submitButton = document.querySelector('#addUserForm button[type="submit"]');
    const originalButtonText = submitButton.innerHTML;
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>處理中...';
    
    const response = await fetch(config.apiUrl+'/api/register', {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
        
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ email, password, role: 1 }) // 默認權限為「只讀」
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();
    if (result.success) {
      // 顯示成功提示
      showNotification('用戶新增成功', 'success');
      
      closeAddUserModal(); // 關閉 Modal
      fetchUsers(); // 刷新用戶列表
    } else {
      showNotification(`用戶新增失敗: ${result.message}`, 'error');
    }
  } catch (error) {
    console.error('Failed to add user:', error);
    showNotification(`新增用戶時發生錯誤: ${error.message}`, 'error');
  } finally {
    // 恢復提交按鈕狀態
    const submitButton = document.querySelector('#addUserForm button[type="submit"]');
    submitButton.disabled = false;
    submitButton.innerHTML = '<i class="fas fa-user-plus mr-2"></i>新增';
  }
}

// 顯示創建公告 Modal
function showCreateAnnouncementModal() {
  const modal = document.getElementById('createAnnouncementModal');
  modal.style.display = 'block';
  
  // 重置表單
  document.getElementById('announcementForm').reset();
  
  // 聚焦到標題輸入框
  document.getElementById('announcementTitle').focus();
}

// 關閉創建公告 Modal
function closeCreateAnnouncementModal() {
  document.getElementById('createAnnouncementModal').style.display = 'none';
}

// 關閉查看公告 Modal
function closeViewAnnouncementModal() {
  document.getElementById('viewAnnouncementModal').style.display = 'none';
}

// 顯示刪除公告確認 Modal
function showDeleteAnnouncementModal() {
  // 獲取當前公告ID
  const announcementId = document.getElementById('announcementActions').dataset.announcementId;
  if (!announcementId) return;
  
  // 保存ID到刪除確認按鈕
  const confirmDeleteBtn = document.querySelector('#deleteAnnouncementModal .btn-danger');
  confirmDeleteBtn.dataset.announcementId = announcementId;
  
  // 顯示確認 Modal
  document.getElementById('deleteAnnouncementModal').style.display = 'block';
  
  // 關閉詳情 Modal
  closeViewAnnouncementModal();
}

// 關閉刪除公告確認 Modal
function closeDeleteAnnouncementModal() {
  document.getElementById('deleteAnnouncementModal').style.display = 'none';
}

// 確認刪除公告
function confirmDeleteAnnouncement() {
  const deleteButton = document.querySelector('#deleteAnnouncementModal .btn-danger');
  const announcementId = deleteButton.dataset.announcementId;
  
  if (!announcementId) return;
  
  // 禁用刪除按鈕並顯示加載狀態
  deleteButton.disabled = true;
  deleteButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>處理中...';
  
  fetch(config.apiUrl+`/api/announcements/${announcementId}`, {
    method: 'DELETE',
    credentials: "include",
    headers: {
      
      'Access-Control-Allow-Origin': '*'
    }
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(result => {
      if (result.success) {
        // 顯示成功提示
        showNotification('公告已成功刪除', 'success');
        
        // 關閉刪除確認 Modal
        closeDeleteAnnouncementModal();
        
        // 重新載入公告列表
        fetchAnnouncements();
      } else {
        throw new Error(result.message || '刪除失敗');
      }
    })
    .catch(error => {
      console.error('Failed to delete announcement:', error);
      showNotification(`刪除公告失敗: ${error.message}`, 'error');
    })
    .finally(() => {
      // 恢復刪除按鈕狀態
      deleteButton.disabled = false;
      deleteButton.innerHTML = '<i class="fas fa-trash-alt mr-2"></i>刪除';
    });
}

// 顯示編輯公告 Modal
function showEditAnnouncementModal() {
  // 獲取當前公告ID
  const announcementId = document.getElementById('announcementActions').dataset.announcementId;
  if (!announcementId) return;
  
  // 獲取公告詳情
  fetch(config.apiUrl+`/api/announcements/${announcementId}`, {
    credentials: "include",
    headers: {
      
      'Access-Control-Allow-Origin': '*'
    }
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then(announcement => {
      // 填充表單
      document.getElementById('announcementTitle').value = announcement.title;
      document.getElementById('announcementContent').value = announcement.content;
      document.getElementById('announcementType').value = announcement.type;
      
      // 設置表單提交處理為編輯模式
      const form = document.getElementById('announcementForm');
      form.dataset.mode = 'edit';
      form.dataset.announcementId = announcementId;
      
      // 更改表單標題
      document.querySelector('#createAnnouncementModal .modal-title').textContent = '編輯公告';
      
      // 更改提交按鈕文字
      const submitButton = form.querySelector('button[type="submit"]');
      submitButton.innerHTML = '<i class="fas fa-save mr-2"></i>保存';
      
      // 關閉詳情 Modal 並打開編輯 Modal
      closeViewAnnouncementModal();
      document.getElementById('createAnnouncementModal').style.display = 'block';
    })
    .catch(error => {
      console.error('Failed to fetch announcement for editing:', error);
      showNotification('無法獲取公告詳情進行編輯', 'error');
    });
}

// 處理公告表單提交
document.addEventListener('DOMContentLoaded', () => {
  const announcementForm = document.getElementById('announcementForm');
  
  if (announcementForm) {
    announcementForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const title = document.getElementById('announcementTitle').value;
      const content = document.getElementById('announcementContent').value;
      const type = document.getElementById('announcementType').value;
      
      if (!title || !content) {
        showNotification('請填寫所有必填欄位', 'error');
        return;
      }
      
      // 禁用提交按鈕並顯示加載狀態
      const submitButton = this.querySelector('button[type="submit"]');
      const originalButtonText = submitButton.innerHTML;
      submitButton.disabled = true;
      submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>處理中...';
      
      try {
        const isEditMode = this.dataset.mode === 'edit';
        const url = isEditMode 
          ? config.apiUrl+`/api/announcements/${this.dataset.announcementId}`
          : config.apiUrl+'/api/announcements';
        
        const method = isEditMode ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
          method: method,
          credentials: "include",
          headers: {
            'Content-Type': 'application/json',
            
            'Access-Control-Allow-Origin': '*'
          },
          body: JSON.stringify({ title, content, type })
        });
        
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
          // 顯示成功提示
          showNotification(isEditMode ? '公告已成功更新' : '公告已成功發佈', 'success');
          
          // 關閉 Modal
          closeCreateAnnouncementModal();
          
          // 重置表單為創建模式
          this.dataset.mode = 'create';
          delete this.dataset.announcementId;
          
          // 恢復表單標題和按鈕文字
          document.querySelector('#createAnnouncementModal .modal-title').textContent = '發佈公告';
          submitButton.innerHTML = '<i class="fas fa-paper-plane mr-2"></i>發佈';
          
          // 重新載入公告列表
          fetchAnnouncements();
        } else {
          throw new Error(result.message || (isEditMode ? '更新失敗' : '發佈失敗'));
        }
      } catch (error) {
        console.error(this.dataset.mode === 'edit' ? 'Failed to update announcement:' : 'Failed to create announcement:', error);
        showNotification(this.dataset.mode === 'edit' ? `更新公告失敗: ${error.message}` : `發佈公告失敗: ${error.message}`, 'error');
      } finally {
        // 恢復提交按鈕狀態
        submitButton.disabled = false;
        submitButton.innerHTML = originalButtonText;
      }
    });
  }
});

// 頁面加載時加載用戶設定和初始化深色模式
// window.onload = function () {
//   loadSettings();
//   updateProfileAvatar();
//   initDarkMode();
//   checkUserPermissions();
// };

// 原有代碼保持不變，添加以下內容

// 在showPage函數中添加對頁面文本的更新
const originalShowPage = window.showPage || function() {};
window.showPage = function(pageId) {
  // 調用原始函數
  originalShowPage(pageId);
  
  // 確保頁面顯示後更新所有文本
  if (typeof updateAllTexts === 'function') {
    setTimeout(updateAllTexts, 50);
  }
};

// 修改原有的加載數據函數，確保所有動態生成的內容都支持國際化
// 這裡只展示一個例子，您需要對所有動態生成內容的函數進行類似修改

// 假設有個函數叫做 renderLogs，將其修改為:
const originalRenderLogs = window.renderLogs || function() {};
window.renderLogs = function(logs) {
  // 先清空表格
  const tableBody = document.getElementById('logTableBody');
  tableBody.innerHTML = '';
  
  // 渲染日誌
  logs.forEach(log => {
    const row = document.createElement('tr');
    const data = new Date(log.timestamp)
    const year = data.getFullYear();
    const month = data.getMonth() + 1; // 月份从0开始，所以要加1
    const day = data.getDate();
    const hours = data.getHours();
    const minutes = data.getMinutes();
    const seconds = data.getSeconds();
    const formattedDate = `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')} ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    row.innerHTML = `
      <td>${formattedDate}</td>
      <td>${log.userEmail}</td>
      <td>${log.type}</td>
      <td>${log.description}</td>
      <td>${log.ipAddress}</td>
    `;
    row.addEventListener('click', () => showLogDetails(log));
    tableBody.appendChild(row);
  });
};

// 修改 showAddUserModal，確保在打開模態框時更新文本
const originalShowAddUserModal = window.showAddUserModal || function() {};
window.showAddUserModal = function() {
  originalShowAddUserModal();
  if (typeof updateAllTexts === 'function') {
    updateAllTexts();
  }
};

function showLogDetails(log) {
  // 获取日志详情模态框元素
  const modal = document.getElementById('logDetailModal');
  const time = document.getElementById('logDetail-time');
  const user = document.getElementById('logDetail-user');
  const ip = document.getElementById('logDetail-ip');
  const type = document.getElementById('logDetail-type');
  const description = document.getElementById('logDetail-description');
  const date = document.getElementById('logDetail-data');

  // 设置日志时间
  time.textContent = log.timestamp;

  // 设置日志用户
  user.textContent = log.userEmail;

  // 设置日志IP地址
  ip.textContent = log.ipAddress;

  // 设置日志类型
  type.textContent = log.type
  description.textContent = log.description

  // 格式化并显示详细数据
  try {
    const formattedData = JSON.stringify(log.data, null, 2);
    date.textContent = formattedData;
  } catch (error) {
    date.textContent = '無詳細數據';
  }

  // 显示模态框
  modal.style.display = 'block';
}

// 关闭日志详情模态框
function closeLogDetailModal() {
  const modal = document.getElementById('logDetailModal');
  modal.style.display = 'none';
}