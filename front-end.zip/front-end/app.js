var config = {};
fetch('config.json').then(response => {
  if(!response.ok) {
    throw new Error("Failed to load config.json");
  }
  return response.json();
}).then(data => {
  config = data
  v();
}).catch(error => {
  console.error(error);
});
async function v() {
  try {
    const response = await fetch(config.apiUrl+'/api/me', {
      credentials: "include",
    });
    
    if (response.status == 200) {
      window.location.href = "dashboard.html"
    }
  } catch (error) {
    console.error('檢查用戶權限失敗:', error);
  }
}

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  // 檢查 Email 和密碼是否為空
  if (!email || !password) {
    document.getElementById('message').innerText = 'Email and password cannot be empty.';
    return;
  }

  // 加密登入信息（這裡使用簡單的 Base64 加密，實際應用中應使用更安全的加密方式）
  const encryptedData = btoa(JSON.stringify({ email, password }));
  try {
    data = {};
    const response = fetch(config.apiUrl+'/api/login', {
      method: 'POST',
      credentials: "include",
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
      body: JSON.stringify({ data: encryptedData })
    }).then(response => {
      if (!response.status === 200) {
        throw new Error(`HTTP error: ${response.status}`);
      }
      return response.json();
    }).then(data => {
      if (data.success) {
        window.location.href = "dashboard.html";
      } else {
        document.getElementById('message').innerText = 'Falied to login.';
      }
    }).catch(error => {
      throw new Error(`HTTP error! Status: ${response.status}`);
    });
  } catch (error) {
    console.error('登入失敗:', error);
  }
});