// 待辦事項功能 - API版本
var config = {};
fetch('config.json').then(response => {
  if(!response.ok) {
    throw new Error("Failed to load config.json");
  }
  return response.json();
}).then(data => {
  config = data
  initTodoList()
}).catch(error => {
  console.error(error);
});

// 用於存儲待辦事項的數組
let tasks = [];
let currentTaskId = null;

// 初始化函數
async function initTodoList() {
  // 從API加載任務
  await fetchTasks();
  
  // 更新任務統計
  updateTaskStats();
  
  // 渲染任務列表
  renderTasks();
  
  // 設置事件監聽器
  document.getElementById('addTaskForm').addEventListener('submit', handleAddTask);
  document.getElementById('editTaskForm').addEventListener('submit', handleEditTask);
}

// 在頁面加載時初始化
document.addEventListener('DOMContentLoaded', function() {
  // initTodoList();
});
// 從API獲取任務
async function fetchTasks() {
  try {
    const response = await fetch(config.apiUrl+'/api/todo', {
      credentials: "include"
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch tasks');
    }
    
    tasks = await response.json();
  } catch (error) {
    console.error('Error fetching tasks:', error);
    // 如果API請求失敗，顯示錯誤提示
    showErrorNotification(t('errors.failedToLoadTasks'));
  }
}

// 渲染任務列表 - 支持多語言
function renderTasks() {
  const taskList = document.getElementById('taskList');
  const filteredTasks = getFilteredTasks();
  
  // 清空任務列表
  taskList.innerHTML = '';
  
  if (filteredTasks.length === 0) {
    // 顯示空狀態
    taskList.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-tasks empty-state-icon"></i>
        <h3 class="empty-state-text">${t('todoList.emptyState.title')}</h3>
        <p class="empty-state-subtext">${t('todoList.emptyState.description')}</p>
      </div>
    `;
    return;
  }
  
  // 排序任務：先顯示待辦事項，按優先級和到期日排序
  filteredTasks.sort((a, b) => {
    // 排序邏輯保持不變
    // ...
  });
  
  // 渲染每個任務
  filteredTasks.forEach(task => {
    // 檢查是否逾期
    let isOverdue = false;
    if (task.status === 'pending' && task.dueDate) {
      const dueDate = new Date(task.dueDate);
      dueDate.setHours(23, 59, 59);
      isOverdue = dueDate < new Date();
    }
    
    // 創建任務元素 - 使用翻譯函數t()
    const taskElement = document.createElement('div');
    taskElement.className = `task-item ${task.status === 'completed' ? 'task-completed' : ''}`;
    taskElement.innerHTML = `
      <input type="checkbox" class="task-checkbox" ${task.status === 'completed' ? 'checked' : ''}>
      <div class="task-content">
        <h3 class="task-title">
          ${task.title}
          ${task.priority === 'high' ? `<span class="priority-badge priority-high" title="${t('todoList.high')}"></span>` : ''}
          ${task.priority === 'medium' ? `<span class="priority-badge priority-medium" title="${t('todoList.medium')}"></span>` : ''}
          ${task.priority === 'low' ? `<span class="priority-badge priority-low" title="${t('todoList.low')}"></span>` : ''}
        </h3>
        ${task.description ? `<p class="task-description">${task.description}</p>` : ''}
        <div class="task-meta">
          ${task.dueDate ? `
            <div class="task-due-date ${isOverdue ? 'overdue' : ''}">
              <i class="fas fa-calendar-alt"></i>
              <span>${formatDate(task.dueDate)}${isOverdue ? ` (${t('todoList.overdueLabel')})` : ''}</span>
            </div>
          ` : ''}
          <div class="task-priority">
            <i class="fas fa-flag"></i>
            <span>${t('todoList.' + task.priority)}</span>
          </div>
        </div>
      </div>
      <div class="task-actions">
        <button class="task-action-btn edit" title="${t('todoList.edit')}">
          <i class="fas fa-edit"></i>
        </button>
        <button class="task-action-btn delete" title="${t('todoList.delete')}">
          <i class="fas fa-trash-alt"></i>
        </button>
      </div>
    `;
    
    // 設置任務勾選事件
    const checkbox = taskElement.querySelector('.task-checkbox');
    checkbox.addEventListener('change', () => {
      toggleTaskStatus(task.id);
    });
    
    // 設置編輯按鈕事件
    const editBtn = taskElement.querySelector('.task-action-btn.edit');
    editBtn.addEventListener('click', () => {
      showEditTaskModal(task.id);
    });
    
    // 設置刪除按鈕事件
    const deleteBtn = taskElement.querySelector('.task-action-btn.delete');
    deleteBtn.addEventListener('click', () => {
      showDeleteTaskModal(task.id);
    });
    
    // 添加到任務列表
    taskList.appendChild(taskElement);
  });
}
function showDeleteTaskModal(taskId) {
  currentTaskId = taskId;
  const modal = document.getElementById('deleteTaskModal');
  modal.style.display = 'flex';
}

// 格式化日期 - 支持當前語言
function formatDate(dateString) {
  const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
  var a = "en-US"
  if (currentLanguage == "zh_TW") {
    a = "zh-TW"
  } else if (currentLanguage == "ja_JP") {
    a = "ja-JP"
  } else if (currentLanguage == "en_US") {
    a = "en-US"
  }
  return new Date(dateString).toLocaleDateString(a, options);
}

function showErrorNotification(message) {
  console.error('Error:', message);
  // 簡單的彈出式提示
  alert(message);
}

// 顯示成功通知
function showSuccessNotification(message) {
  console.log('Success:', message);
  // 簡單的彈出式提示
  alert(message);
}
function filterTasks() {
  renderTasks();
}

// 按篩選條件獲取任務的函數
function getFilteredTasks() {
  // 獲取篩選條件
  const statusFilter = document.getElementById('statusFilter')?.value || 'all';
  const priorityFilter = document.getElementById('priorityFilter')?.value || 'all';
  const dueDateFilter = document.getElementById('dueDateFilter')?.value || 'all';
  const searchTerm = (document.getElementById('taskSearch')?.value || '').toLowerCase();
  
  // 如果任務為空，返回空數組
  if (!tasks || !Array.isArray(tasks)) {
    return [];
  }
  
  return tasks.filter(task => {
    // 狀態篩選
    if (statusFilter !== 'all' && task.status !== statusFilter) {
      return false;
    }
    
    // 優先級篩選
    if (priorityFilter !== 'all' && task.priority !== priorityFilter) {
      return false;
    }
    
    // 截止日期篩選
    if (dueDateFilter !== 'all') {
      const today = new Date();
      const dueDate = new Date(task.dueDate);
      switch (dueDateFilter) {
        case 'today':
          if (!isSameDay(dueDate, today)) return false;
          break;
        case 'thisWeek':
          if (!isSameWeek(dueDate, today)) return false;
          break;
        case 'overdue':
          if (dueDate >= today) return false;
          break;
        default:
          break;
      }
    }
    // 搜索關鍵字篩選
    if (searchTerm && !task.title.toLowerCase().includes(searchTerm) && !task.description.toLowerCase().includes(searchTerm)) {
      return false;
    }
    
    return true;
  });
}

// 打開新增任務模態框
function showAddTaskModal() {
  // 設置默認日期為今天
  const today = new Date().toISOString().split('T')[0];
  const dueDateInput = document.getElementById('taskDueDate');
  if (dueDateInput) {
    dueDateInput.value = today;
  }
  
  // 重置表單
  const form = document.getElementById('addTaskForm');
  if (form) {
    form.reset();
  }
  
  // 顯示 Modal
  const modal = document.getElementById('addTaskModal');
  if (modal) {
    modal.style.display = 'flex';
  }
}

function updateTaskStats() {
  // 獲取用於顯示統計信息的DOM元素
  const totalTasksElement = document.getElementById('totalTaskCount');
  const completedTasksElement = document.getElementById('completedTaskCount');
  const pendingTasksElement = document.getElementById('pendingTaskCount');
  const overdueTasksElement = document.getElementById('overdueTaskCount');

  // 如果DOM元素不存在，直接返回
  if (!totalTasksElement || !completedTasksElement || !pendingTasksElement || !overdueTasksElement) {
    return;
  }

  // 計算任務統計信息
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.status === 'completed').length;
  const pendingTasks = tasks.filter(task => task.status === 'pending').length;


  totalTasksElement.textContent = totalTasks;
  completedTasksElement.textContent = completedTasks;
  pendingTasksElement.textContent = pendingTasks;
  overdueTasksElement.textContent = "Never applies"


  // 計算逾期任務的數量
  const overdueTasks = tasks.filter(task => {
    if (task.status === 'pending' && task.dueDate) {
      const dueDate = new Date(task.dueDate);
      dueDate.setHours(23, 59, 59);
      return dueDate < new Date();
    }
    return false;
  }).length;

  // 更新DOM元素中的統計信息
  totalTasksElement.textContent = totalTasks;
  completedTasksElement.textContent = completedTasks;
  pendingTasksElement.textContent = pendingTasks;
  overdueTasksElement.textContent = overdueTasks;
}
async function handleAddTask(event) {
  event.preventDefault(); // 阻止表單的默認提交行為

  // 獲取表單輸入的值
  const title = document.getElementById('taskTitle').value.trim();
  const description = document.getElementById('taskDescription').value.trim();
  const dueDate = document.getElementById('taskDueDate').value;
  const priority = document.getElementById('taskPriority').value;

  // 簡單的輸入驗證
  if (!title) {
    showErrorNotification(t('errors.taskTitleRequired'));
    return;
  }

  try {
    // 創建新任務對象
    const newTask = {
      id: Date.now(), // 使用時間戳作為唯一ID
      title,
      description,
      dueDate,
      priority,
      status: 'pending', // 默認狀態為待辦
      createdAt: new Date().toISOString(), // 記錄創建時間
    };

    // 發送請求到API以添加任務
    const response = await fetch(config.apiUrl + '/api/todo', {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newTask),
    });

    if (!response.ok) {
      throw new Error('Failed to add task');
    }

    // 將新任務添加到本地任務數組
    const addedTask = await response.json();
    tasks.push(addedTask);

    // 更新任務列表和統計信息
    renderTasks();
    updateTaskStats();

    // 顯示成功通知
    showSuccessNotification(t('notifications.taskAddedSuccessfully'));

    // 關閉新增任務模態框
    const modal = document.getElementById('addTaskModal');
    if (modal) {
      modal.style.display = 'none';
    }

    // 重置表單
    event.target.reset();
  } catch (error) {
    console.error('Error adding task:', error);
    showErrorNotification(t('errors.failedToAddTask'));
  }
}
async function handleEditTask(event) {
  event.preventDefault(); // 阻止表單的默認提交行為

  // 獲取表單數據
  const formData = new FormData(event.target);
  const taskId = currentTaskId; // 從全局變量中獲取當前編輯的任務 ID
  const updatedTask = {
    title: formData.get('title'),
    description: formData.get('description'),
    dueDate: formData.get('dueDate'),
    priority: formData.get('priority'),
    status: formData.get('status') || 'pending', // 如果未設置狀態，默認為 pending
  };

  try {
    // 發送更新請求到 API
    const response = await fetch(`${config.apiUrl}/api/todo/${taskId}`, {
      method: 'PUT', // 使用 PUT 方法更新任務
      credentials: "include",
      headers: {
        'Content-Type': 'application/json'// 假設使用 PASETO 進行身份驗證
      },
      body: JSON.stringify(updatedTask),
    });

    if (!response.ok) {
      throw new Error('Failed to update task');
    }

    // 更新本地任務列表
    const updatedTaskData = await response.json();
    const taskIndex = tasks.findIndex(task => task.id === taskId);
    if (taskIndex !== -1) {
      tasks[taskIndex] = updatedTaskData; // 更新本地任務數據
    }

    // 重新渲染任務列表
    renderTasks();

    // 更新任務統計
    updateTaskStats();

    // 顯示成功通知

    // 關閉編輯模態框
    const editModal = document.getElementById('editTaskModal');
    if (editModal) {
      editModal.style.display = 'none';
    }
  } catch (error) {
    console.error('Error updating task:', error);
    showErrorNotification(t('errors.failedToUpdateTask'));
  }
}
async function confirmDeleteTask() {
  if (!currentTaskId) return;
  
  // 從列表中刪除任務
  tasks = tasks.filter(task => task.id !== currentTaskId);

  fetch(config.apiUrl + '/api/todo/' + currentTaskId, {
    method: 'DELETE'
  })
  
  // 保存任務
  saveTasks();
  
  // 更新 UI
  updateTaskStats();
  renderTasks();
  
  // 關閉 Modal
  closeDeleteTaskModal();
}
function closeDeleteTaskModal() {
  const modal = document.getElementById('deleteTaskModal');
  modal.style.display = 'none';
  currentTaskId = null;
}
function closeDeleteTaskModal() {
  const modal = document.getElementById('deleteTaskModal');
  modal.style.display = 'none';
  currentTaskId = null;
}
function toggleTaskStatus(taskId) {
  const taskIndex = tasks.findIndex(t => t.id === taskId);
  if (taskIndex === -1) return;
  
  // 切換狀態
  const newStatus = tasks[taskIndex].status === 'completed' ? 'pending' : 'completed';
  tasks[taskIndex].status = newStatus;
  
  // 更新完成時間
  if (newStatus === 'completed') {
    tasks[taskIndex].completedAt = new Date().toISOString();
  } else {
    delete tasks[taskIndex].completedAt;
  }
  
  // 保存任務
  saveTasks();
  
  // 更新 UI
  updateTaskStats();
  renderTasks();
}
function saveTasks() {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}

function showEditTaskModal(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;
  
  // 保存當前正在編輯的任務 ID
  currentTaskId = taskId;
  
  // 填充表單
  document.getElementById('editTaskId').value = task.id;
  document.getElementById('editTaskTitle').value = task.title;
  document.getElementById('editTaskDescription').value = task.description || '';
  document.getElementById('editTaskDueDate').value = task.dueDate || '';
  document.getElementById('editTaskPriority').value = task.priority;
  document.getElementById('editTaskStatus').value = task.status;
  
  // 顯示 Modal
  const modal = document.getElementById('editTaskModal');
  modal.style.display = 'flex';
}

// 關閉編輯任務 Modal
function closeEditTaskModal() {
  const modal = document.getElementById('editTaskModal');
  modal.style.display = 'none';
  currentTaskId = null;
}

function closeAddTaskModal() {
  const modal = document.getElementById('addTaskModal');
  modal.style.display = 'none';
}
function toggleFilterMenu() {
  const filterMenu = document.getElementById('todoFilterMenu');
  filterMenu.style.display = filterMenu.style.display === 'none' ? 'block' : 'none';
}
function searchTasks() {
  renderTasks();
}