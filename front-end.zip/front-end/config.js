var config = {};

fetch('config.json')
  .then(response => {
    if (!response.ok) {
      throw new Error('Failed to load config.json');
    }
    return response.json();
  })
  .then(data => {
    config = data;
    console.log('Config loaded:', config);
    // 設置背景圖片
    if (config.backgroundImage) {
      document.body.style.backgroundImage = `url(${config.backgroundImage})`;
    }
  })
  .catch(error => {
    console.error('Error loading config:', error);
  });