var config = {};
fetch('config.json').then(response => {
  if(!response.ok) {
    throw new Error("Failed to load config.json");
  }
  return response.json();
}).then(data => {
  config = data
})
// 跳轉到控制台
function goToDashboard() {
  window.location.href = 'dashboard.html';
}
// 加載保存的用戶設定
async function loadSettings() {
  try {
    const response = await fetch(config.apiUrl+'/api/api/user/settings', {
      credentials: "include"
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const settings = await response.json();
    if (settings) {
      // 更新用戶名和頭像
      document.getElementById('username').value = settings.username || '';
      const avatarPreview = document.getElementById('avatarPreview');
      if (avatarPreview) {
        avatarPreview.src = settings.avatar || 'default-avatar.png';
      }
    }
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

// 保存用戶設定
document.getElementById('settingsForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const username = document.getElementById('username').value;
  const avatarFile = document.getElementById('avatar').files[0];

  

  let avatar = null;
  if (avatarFile) {
    const reader = new FileReader();
    reader.onload = function (e) {
      avatar = e.target.result;
      saveSettings(username, avatar);
    };
    reader.readAsDataURL(avatarFile);
  } else {
    try {
      const response = await fetch(config.apiUrl+'/api/api/user/settings', {
        credentials: "include"
      });
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const settings = await response.json();
      saveSettings(username, settings.avatar);
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  }
});

async function saveSettings(username, avatar) {
  try {
    const response = await fetch(config.apiUrl+'/api/api/user/settings', {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, avatar })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();
    if (result.success) {
      alert('設定已保存');
    } else {
      alert(`設定保存失敗: ${result.message}`);
    }
  } catch (error) {
    console.error('Failed to save settings:', error);
  }
}
// 頁面加載時加載用戶設定
window.onload = function () {
  loadSettings();
};