import http.server
import socketserver
import os

# 設置端口
PORT = 8000

# 設置當前目錄為根目錄
web_dir = os.path.join(os.path.dirname(__file__))
os.chdir(web_dir)

# 啟動 HTTP 伺服器
Handler = http.server.SimpleHTTPRequestHandler
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving at http://localhost:{PORT}")
    httpd.serve_forever()